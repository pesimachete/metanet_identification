import typing
import jax
import jax.numpy as jnp
from .parameter_handling import Theta
from jax import tree_util


class AdamState(typing.NamedTuple):
    m: Theta  # first moment
    v: Theta  # second moment


class LearningState(typing.NamedTuple):
    theta: Theta
    z: typing.Any
    adam: AdamState
    adam_eps: float
    mcmc_variance: jax.Array
    k: jax.Array


class StepDiagnostic(typing.NamedTuple):
    k: int
    gamma: float
    grad_norm: float


class RunResult(typing.NamedTuple):
    state: LearningState
    theta_history: list[Theta]
    lr_history: list[float]
    grad_norm_history: list[float]
    diagnostics: list[StepDiagnostic]


def init_adam(theta: Theta) -> AdamState:
    return AdamState(
        m=jax.tree.map(jnp.zeros_like, theta), v=jax.tree.map(jnp.zeros_like, theta)
    )


def adam_update(
    state: AdamState, g: Theta, b1: float = 0.9, b2: float = 0.999
) -> AdamState:

    g_clipped = jax.tree.map(lambda gi: jnp.clip(gi, -1e10, 1e10), g)

    m_new = jax.tree.map(lambda m, gi: b1 * m + (1.0 - b1) * gi, state.m, g_clipped)
    v_new = jax.tree.map(
        lambda v, gi: b2 * v + (1.0 - b2) * (gi**2), state.v, g_clipped
    )

    return AdamState(m=m_new, v=v_new)


def adam_apply(
    state: AdamState, eps: float, k: jax.Array, b1: float = 0.9, b2: float = 0.999
) -> Theta:
    # k is 1-indexed for bias correction
    def compute_update(m, v):
        m_hat = m / (1.0 - b1**k)
        v_hat = v / (1.0 - b2**k)
        return m_hat / (jnp.sqrt(v_hat) + eps)

    return jax.tree.map(compute_update, state.m, state.v)


def compute_lr_jax_constant(
    k: jax.Array,
    k_pre: int,
    k_end_heat: jax.Array,
    heat_ended: jax.Array,
    gamma_0: float,
    alpha_decay: float,
) -> jax.Array:
    # Bypass the pre-heat and cooling schedule
    return jnp.asarray(gamma_0, dtype=jnp.float32)
